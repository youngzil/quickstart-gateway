<a name="SpuAttributes1212Breakfast"></a>
## SpuAttributes1212Breakfast
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**type** | [**EnumType**](#EnumType) | 加早类型; 0 - 不支持加早; 1 - 早餐; 2 - 自助早餐 |  required 
**price** | **Integer** | 加早费用/每人，单位人民币分 不支持加早填0 |  required 

<a name="EnumType"></a>
### Enum: EnumType
Name | Value
---- | -----
NUMBER_0 | 0
NUMBER_1 | 1
NUMBER_2 | 2



