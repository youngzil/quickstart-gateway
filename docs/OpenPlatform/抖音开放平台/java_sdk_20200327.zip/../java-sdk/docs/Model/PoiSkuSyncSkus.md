<a name="PoiSkuSyncSkus"></a>
## PoiSkuSyncSkus
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**price** | **Integer** | 价格(人民币分) |  required 
**stock** | **Integer** | 库存数量 |  required 
**status** | [**OnlineStatus**](#OnlineStatus) |  |  required 
**attributes** | [**SkuAttributes**](#SkuAttributes) |  |  required 



<markdown src="./OnlineStatus.md"/>
<markdown src="./SkuAttributes.md"/>
