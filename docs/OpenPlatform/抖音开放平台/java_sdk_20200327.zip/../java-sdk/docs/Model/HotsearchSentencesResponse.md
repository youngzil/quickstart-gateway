<a name="HotsearchSentencesResponse"></a>
## HotsearchSentencesResponse
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**data** | [**HotsearchSentencesResponseData**](#HotsearchSentencesResponseData) |  |  optional

<markdown src="./HotsearchSentencesResponseData.md"/>
