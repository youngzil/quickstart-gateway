<a name="VideoCommentReplyBody"></a>
## VideoCommentReplyBody
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**itemId** | **String** | 视频id |  required 
**commentId** | **String** | 需要回复的评论id |  required 
**content** | **String** | 评论内容 |  required 




