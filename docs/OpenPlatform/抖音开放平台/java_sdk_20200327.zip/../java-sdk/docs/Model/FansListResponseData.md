<a name="FansListResponseData"></a>
## FansListResponseData
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**errorCode** | **Integer** |  |  optional
**description** | **String** |  |  optional
**cursor** | **Long** |  |  optional
**hasMore** | **Boolean** |  |  optional
**list** | [**List&lt;User&gt;**](#User) |  |  optional
**total** | **Integer** | 粉丝总数 |  optional





<markdown src="./User.md"/>

