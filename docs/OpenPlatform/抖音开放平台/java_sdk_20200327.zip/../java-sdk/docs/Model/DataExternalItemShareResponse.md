<a name="DataExternalItemShareResponse"></a>
## DataExternalItemShareResponse
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**data** | [**DataExternalItemShareResponseData**](#DataExternalItemShareResponseData) |  |  optional

<markdown src="./DataExternalItemShareResponseData.md"/>
