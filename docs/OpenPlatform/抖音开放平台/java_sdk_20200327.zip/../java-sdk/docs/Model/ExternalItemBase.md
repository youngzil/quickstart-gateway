<a name="ExternalItemBase"></a>
## ExternalItemBase
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**totalPlay** | **Integer** | 30天播放次数 |  optional
**totalLike** | **Integer** | 30天点赞数 |  optional
**totalComment** | **Integer** | 30天评论数 |  optional
**totalShare** | **Integer** | 30天分享数 |  optional
**avgPlayDuration** | **Double** | 30天平均播放时长 |  optional






