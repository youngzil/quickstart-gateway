<a name="SupplierAttributes2203"></a>
## SupplierAttributes2203
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**enable** | **Integer** | 上线状态(1:上线，2:下线) |  optional
**entry** | [**SupplierAttributes2201Entry**](#SupplierAttributes2201Entry) |  |  optional


<markdown src="./SupplierAttributes2201Entry.md"/>
