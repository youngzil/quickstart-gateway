<a name="SupplierAttributes2201Entry"></a>
## SupplierAttributes2201Entry
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**entryType** | **Integer** | 入口类型(1:H5，2:抖音小程序) |  optional
**entrySchema** | **String** | 服务跳转链接 |  optional



