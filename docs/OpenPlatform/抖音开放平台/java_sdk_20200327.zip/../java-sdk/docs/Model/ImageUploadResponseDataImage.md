<a name="ImageUploadResponseDataImage"></a>
## ImageUploadResponseDataImage
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**imageId** | **String** | 图片id |  required 
**width** | **Integer** |  |  required 
**height** | **Integer** |  |  required 




