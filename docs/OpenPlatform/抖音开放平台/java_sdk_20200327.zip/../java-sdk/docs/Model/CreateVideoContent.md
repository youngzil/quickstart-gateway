<a name="CreateVideoContent"></a>
## CreateVideoContent
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**itemId** | **String** | 创建的视频id |  optional
**shareId** | **String** | 标识分享的share_id |  optional



