<a name="FansDataResponse"></a>
## FansDataResponse
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**data** | [**FansDataResponseData**](#FansDataResponseData) |  |  optional

<markdown src="./FansDataResponseData.md"/>
