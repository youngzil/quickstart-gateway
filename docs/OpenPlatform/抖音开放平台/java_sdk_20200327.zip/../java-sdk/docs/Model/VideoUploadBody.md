<a name="VideoUploadBody"></a>
## VideoUploadBody
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**video** | [**File**](#File) | 视频文件。 注意：    1. multipart/form-data中的Content-Type都必须以\&quot;video/\&quot;开头，如\&quot;video/mp4\&quot;，否则会报错：\&quot;unsupported content type xxx\&quot;。   2. 该Content-Type不是加在Header中，是加在请求体里面：![如图](http://p3.pstatp.com/origin/2dd390008887d044455b9)  |  required 

<markdown src="./File.md"/>
