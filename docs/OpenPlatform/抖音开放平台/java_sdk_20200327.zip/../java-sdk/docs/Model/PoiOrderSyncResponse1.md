<a name="PoiOrderSyncResponse1"></a>
## PoiOrderSyncResponse1
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**data** | [**PoiOrderSyncResponse1Data**](#PoiOrderSyncResponse1Data) |  |  required 

<markdown src="./PoiOrderSyncResponse1Data.md"/>
