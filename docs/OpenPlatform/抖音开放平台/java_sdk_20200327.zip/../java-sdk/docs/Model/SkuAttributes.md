<a name="SkuAttributes"></a>
## SkuAttributes
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**_1301** | **String** | 酒店、名宿SKU日期 |  optional


