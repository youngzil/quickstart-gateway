<a name="ExternalItemPlay"></a>
## ExternalItemPlay
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**date** | **String** | 日期 |  optional
**play** | **Integer** | 每日播放数 |  optional



