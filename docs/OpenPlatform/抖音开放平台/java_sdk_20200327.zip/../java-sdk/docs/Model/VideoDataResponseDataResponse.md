<a name="VideoDataResponseDataResponse"></a>
## VideoDataResponseDataResponse
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**itemId** | **String** | 抖音视频id |  required 
**title** | **String** | 视频文字 |  required 
**createTime** | **Integer** | 视频创建时间戳 |  required 
**digg** | **Integer** | 点赞数 |  required 
**play** | **Integer** | 播放数 |  required 
**forward** | **Integer** | 转发数 |  required 
**isReviewed** | **Boolean** | 是否审核通过 |  required 








