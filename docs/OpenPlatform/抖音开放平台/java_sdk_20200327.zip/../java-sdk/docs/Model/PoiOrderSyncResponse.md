<a name="PoiOrderSyncResponse"></a>
## PoiOrderSyncResponse
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**appId** | **String** | 小程序的appid |  required 
**userOpenId** | **String** | 用户的抖音小程序openid |  required 



