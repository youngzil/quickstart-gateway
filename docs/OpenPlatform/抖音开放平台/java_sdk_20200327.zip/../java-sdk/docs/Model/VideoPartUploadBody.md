<a name="VideoPartUploadBody"></a>
## VideoPartUploadBody
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**video** | [**File**](#File) | 视频分片，建议20MB。但不能小于5MB。  |  required 

<markdown src="./File.md"/>
