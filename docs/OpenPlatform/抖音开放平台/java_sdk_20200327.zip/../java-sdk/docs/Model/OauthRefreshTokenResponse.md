<a name="OauthRefreshTokenResponse"></a>
## OauthRefreshTokenResponse
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**message** | **String** |  |  optional
**data** | [**OauthRefreshTokenResponseData**](#OauthRefreshTokenResponseData) |  |  optional


<markdown src="./OauthRefreshTokenResponseData.md"/>
