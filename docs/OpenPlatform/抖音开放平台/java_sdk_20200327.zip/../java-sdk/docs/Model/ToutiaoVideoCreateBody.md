<a name="ToutiaoVideoCreateBody"></a>
## ToutiaoVideoCreateBody
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**videoId** | **String** | video_id, 通过/toutiao/video/upload/接口得到 |  required 
**text** | **String** | 视频标题不要超过30个字符 |  optional



