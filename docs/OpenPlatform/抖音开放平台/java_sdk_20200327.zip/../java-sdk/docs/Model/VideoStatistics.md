<a name="VideoStatistics"></a>
## VideoStatistics
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**commentCount** | **Integer** | 评论数 |  required 
**diggCount** | **Integer** | 点赞数 |  required 
**downloadCount** | **Integer** | 下载数 |  required 
**playCount** | **Integer** | 播放数，只有作者本人可见。公开视频设为私密后，播放数也会返回0。 |  required 
**shareCount** | **Integer** | 分享数 |  required 
**forwardCount** | **Integer** | 转发数 |  required 







