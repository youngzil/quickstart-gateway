<a name="TrendingSentence"></a>
## TrendingSentence
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**sentence** | **String** | 热点词 |  required 
**hotLevel** | **Integer** | 热度 综合点赞、评论、转发等计算得出 |  required 
**label** | [**EnumLabel**](#EnumLabel) | 标签:   * &#x60;0&#x60; - 无   * &#x60;1&#x60; - 新   * &#x60;2&#x60; - 推荐   * &#x60;3&#x60; - 热   * &#x60;4&#x60; - 爆   * &#x60;5&#x60; - 首发  |  required 

<a name="EnumLabel"></a>
### Enum: EnumLabel
Name | Value
---- | -----
NUMBER_0 | 0
NUMBER_1 | 1
NUMBER_2 | 2
NUMBER_3 | 3
NUMBER_4 | 4
NUMBER_5 | 5




