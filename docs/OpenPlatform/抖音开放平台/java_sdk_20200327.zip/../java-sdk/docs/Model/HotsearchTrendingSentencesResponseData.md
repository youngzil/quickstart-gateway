<a name="HotsearchTrendingSentencesResponseData"></a>
## HotsearchTrendingSentencesResponseData
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**errorCode** | **Integer** |  |  required 
**description** | **String** |  |  required 
**total** | **Integer** |  |  required 
**cursor** | **Long** |  |  required 
**hasMore** | **Boolean** |  |  required 
**list** | [**List&lt;TrendingSentence&gt;**](#TrendingSentence) | 实时热点词 |  optional






<markdown src="./TrendingSentence.md"/>
