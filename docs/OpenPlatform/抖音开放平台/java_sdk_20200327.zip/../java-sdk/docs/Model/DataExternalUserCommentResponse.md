<a name="DataExternalUserCommentResponse"></a>
## DataExternalUserCommentResponse
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**data** | [**DataExternalUserCommentResponseData**](#DataExternalUserCommentResponseData) |  |  optional

<markdown src="./DataExternalUserCommentResponseData.md"/>
