<a name="SpuAttributes1213"></a>
## SpuAttributes1213
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**cancelAmend** | [**SpuAttributes1213Response**](#SpuAttributes1213Response) |  |  required 
**extra** | **String** | 退改政策自定义内容 |  optional

<markdown src="./SpuAttributes1213Response.md"/>

