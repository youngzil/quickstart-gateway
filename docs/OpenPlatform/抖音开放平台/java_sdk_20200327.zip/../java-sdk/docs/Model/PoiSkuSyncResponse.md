<a name="PoiSkuSyncResponse"></a>
## PoiSkuSyncResponse
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**data** | [**PoiSkuSyncResponseData**](#PoiSkuSyncResponseData) |  |  required 

<markdown src="./PoiSkuSyncResponseData.md"/>
