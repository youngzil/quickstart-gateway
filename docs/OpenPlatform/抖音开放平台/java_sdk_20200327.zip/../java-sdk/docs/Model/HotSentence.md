<a name="HotSentence"></a>
## HotSentence
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**hotLevel** | **Integer** | 热度 综合点赞、评论、转发等计算得出 |  required 
**sentence** | **String** | 热点词 |  required 



