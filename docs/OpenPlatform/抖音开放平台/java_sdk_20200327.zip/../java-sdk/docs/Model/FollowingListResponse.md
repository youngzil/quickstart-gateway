<a name="FollowingListResponse"></a>
## FollowingListResponse
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**data** | [**FollowingListResponseData**](#FollowingListResponseData) |  |  required 

<markdown src="./FollowingListResponseData.md"/>
