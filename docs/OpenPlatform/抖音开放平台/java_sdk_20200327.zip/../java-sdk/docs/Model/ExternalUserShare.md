<a name="ExternalUserShare"></a>
## ExternalUserShare
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**date** | **String** | 日期 |  optional
**newShare** | **Integer** | 新增分享 |  optional



