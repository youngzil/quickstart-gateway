<a name="HotsearchSentencesResponseData"></a>
## HotsearchSentencesResponseData
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**errorCode** | **Integer** |  |  required 
**description** | **String** |  |  required 
**activeTime** | **String** | 刷新时间 |  optional
**list** | [**List&lt;HotSentence&gt;**](#HotSentence) | 实时热点词 |  optional




<markdown src="./HotSentence.md"/>
