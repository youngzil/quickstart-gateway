<a name="SupplierAttributes3101Facility"></a>
## SupplierAttributes3101Facility
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**name** | **String** | 设施名称，三方自定义(每项不超过5个汉字) |  optional


