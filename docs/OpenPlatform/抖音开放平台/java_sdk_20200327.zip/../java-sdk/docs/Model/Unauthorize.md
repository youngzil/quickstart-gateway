<a name="Unauthorize"></a>
## Unauthorize
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**event** | **String** | 事件名为unauthorize |  optional
**fromUserId** | **String** | 授权用户user_id |  optional
**clientKey** | **String** | 授权应用的client_key |  optional
**content** | [**AuthorizeContent**](#AuthorizeContent) |  |  optional




<markdown src="./AuthorizeContent.md"/>
