<a name="EnterpriseLeadsTagDeleteResponse"></a>
## EnterpriseLeadsTagDeleteResponse
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**message** | **String** |  |  optional
**data** | [**EnterpriseLeadsTagDeleteResponseData**](#EnterpriseLeadsTagDeleteResponseData) |  |  optional


<markdown src="./EnterpriseLeadsTagDeleteResponseData.md"/>
