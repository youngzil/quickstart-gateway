<a name="OauthRefreshTokenResponseData"></a>
## OauthRefreshTokenResponseData
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**errorCode** | **Integer** |  |  optional
**description** | **String** |  |  optional
**accessToken** | **String** | 接口调用凭证 |  optional
**expiresIn** | **String** | 过期时间，单位（秒） |  optional
**refreshToken** | **String** | 用户刷新 |  optional
**openId** | **String** | 当前应用下，授权用户唯一标识 |  optional
**scope** | **String** | 用户授权的作用域 |  optional








