<a name="ExternalPoiBase"></a>
## ExternalPoiBase
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**date** | **String** | 日期 |  optional
**detailVv** | **Integer** | 详情页pv |  optional



