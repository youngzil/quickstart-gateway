<a name="PoiSearchKeywordResponse"></a>
## PoiSearchKeywordResponse
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**data** | [**PoiSearchKeywordResponseData**](#PoiSearchKeywordResponseData) |  |  optional

<markdown src="./PoiSearchKeywordResponseData.md"/>
