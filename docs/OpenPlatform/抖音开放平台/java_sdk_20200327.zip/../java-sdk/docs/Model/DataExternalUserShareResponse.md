<a name="DataExternalUserShareResponse"></a>
## DataExternalUserShareResponse
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**data** | [**DataExternalUserShareResponseData**](#DataExternalUserShareResponseData) |  |  optional

<markdown src="./DataExternalUserShareResponseData.md"/>
