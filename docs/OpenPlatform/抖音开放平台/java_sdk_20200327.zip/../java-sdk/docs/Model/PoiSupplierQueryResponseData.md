<a name="PoiSupplierQueryResponseData"></a>
## PoiSupplierQueryResponseData
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**syncStatus** | [**SyncStatus**](#SyncStatus) |  |  optional
**errorCode** | **Integer** |  |  required 
**description** | **String** |  |  required 

<markdown src="./SyncStatus.md"/>


