<a name="Extra"></a>
## Extra
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**logId** | **String** |  |  optional
**now** | **Long** |  |  optional



