<a name="OauthUserinfoResponse"></a>
## OauthUserinfoResponse
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**data** | [**OauthUserinfoResponseData**](#OauthUserinfoResponseData) |  |  optional

<markdown src="./OauthUserinfoResponseData.md"/>
