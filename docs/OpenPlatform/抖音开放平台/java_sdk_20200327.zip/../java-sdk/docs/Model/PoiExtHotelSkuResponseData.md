<a name="PoiExtHotelSkuResponseData"></a>
## PoiExtHotelSkuResponseData
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**spuExtId** | **String** | 接入方SPU ID |  required 
**startDate** | **String** | 价格时间区间[start_date, end_date) |  required 
**endDate** | **String** | 价格时间区间[start_date, end_date) |  required 
**price** | **Integer** | 房型价格(人民币分) |  required 
**stock** | **Integer** | 库存量 |  optional






