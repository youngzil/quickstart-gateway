<a name="PoiSupplierSyncResponseData"></a>
## PoiSupplierSyncResponseData
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**supplierId** | **String** | 抖音平台商户ID |  required 
**errorCode** | **Integer** |  |  required 
**description** | **String** |  |  required 




