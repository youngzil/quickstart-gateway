<a name="PoiSearchKeywordResponseData"></a>
## PoiSearchKeywordResponseData
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**errorCode** | **Integer** |  |  required 
**description** | **String** |  |  required 
**cursor** | **Long** |  |  required 
**hasMore** | **Boolean** |  |  required 
**pois** | [**List&lt;Poi&gt;**](#Poi) |  |  optional





<markdown src="./Poi.md"/>
