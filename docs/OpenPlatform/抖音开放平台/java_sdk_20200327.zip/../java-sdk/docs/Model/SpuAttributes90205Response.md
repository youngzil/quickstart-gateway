<a name="SpuAttributes90205Response"></a>
## SpuAttributes90205Response
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**appId** | **String** | 小程序的appid |  optional
**path** | **String** | 服务路径 |  optional
**params** | **String** | 服务参数json |  optional
**isTest** | **Integer** | 主要用于联调，1-使用测试版的小程序，0或者不填-使用正式版小程序 |  optional





