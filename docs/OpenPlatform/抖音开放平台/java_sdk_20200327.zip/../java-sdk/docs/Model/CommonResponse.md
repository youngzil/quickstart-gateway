<a name="CommonResponse"></a>
## CommonResponse
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**data** | [**CommonResponseData**](#CommonResponseData) |  |  required 

<markdown src="./CommonResponseData.md"/>
