<a name="EnterpriseLeadsUserListResponse"></a>
## EnterpriseLeadsUserListResponse
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**data** | [**EnterpriseLeadsUserListResponseData**](#EnterpriseLeadsUserListResponseData) |  |  optional

<markdown src="./EnterpriseLeadsUserListResponseData.md"/>
