<a name="ToutiaoVideoDataBody"></a>
## ToutiaoVideoDataBody
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**itemIds** | **List&lt;String&gt;** | item_id数组，支持查询授权用户上传的视频。 |  required 


