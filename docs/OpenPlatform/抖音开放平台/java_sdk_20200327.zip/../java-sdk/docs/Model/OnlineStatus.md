# OnlineStatus

## Enum

* `NUMBER_1` (value: `1`)
* `NUMBER_2` (value: `2`)
