<a name="PoiSpuQueryResponse"></a>
## PoiSpuQueryResponse
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**data** | [**PoiSpuQueryResponseData**](#PoiSpuQueryResponseData) |  |  required 

<markdown src="./PoiSpuQueryResponseData.md"/>
