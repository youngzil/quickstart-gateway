<a name="ToutiaoVideo"></a>
## ToutiaoVideo
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**itemId** | **String** | 视频id |  required 
**title** | **String** | 视频标题 |  required 
**cover** | **String** | 视频封面 |  required 
**createTime** | **Long** | 视频创建时间戳 |  required 
**statistics** | [**ToutiaoVideoStatistics**](#ToutiaoVideoStatistics) |  |  required 





<markdown src="./ToutiaoVideoStatistics.md"/>
