<a name="Poi"></a>
## Poi
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**poiId** | **String** | 唯一ID |  required 
**poiName** | **String** | 名称 |  required 
**location** | **String** | 经纬度，格式：X,Y |  required 
**country** | **String** | 国家 |  optional
**countryCode** | **String** | 国家编码 |  optional
**province** | **String** | 省份 |  optional
**city** | **String** | 城市 |  optional
**cityCode** | **String** | 城市编码 |  optional
**district** | **String** | 区域名称 |  optional
**address** | **String** | 地址 |  optional











