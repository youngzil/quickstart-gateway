<a name="VideoPartInitResponse"></a>
## VideoPartInitResponse
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**data** | [**VideoPartInitResponseData**](#VideoPartInitResponseData) |  |  optional

<markdown src="./VideoPartInitResponseData.md"/>
