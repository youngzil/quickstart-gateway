<a name="SpuAttributes1212"></a>
## SpuAttributes1212
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**breakfast** | [**SpuAttributes1212Breakfast**](#SpuAttributes1212Breakfast) |  |  required 
**extraBed** | [**SpuAttributes1212Response**](#SpuAttributes1212Response) |  |  required 
**extra** | **String** | 费用政策自定义内容 |  optional

<markdown src="./SpuAttributes1212Breakfast.md"/>
<markdown src="./SpuAttributes1212Response.md"/>

