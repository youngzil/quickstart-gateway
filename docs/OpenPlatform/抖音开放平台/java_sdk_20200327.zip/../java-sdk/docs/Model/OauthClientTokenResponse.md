<a name="OauthClientTokenResponse"></a>
## OauthClientTokenResponse
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**message** | **String** |  |  optional
**data** | [**OauthClientTokenResponseData**](#OauthClientTokenResponseData) |  |  optional


<markdown src="./OauthClientTokenResponseData.md"/>
