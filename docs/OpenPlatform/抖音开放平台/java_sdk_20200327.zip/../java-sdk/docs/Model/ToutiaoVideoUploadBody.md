<a name="ToutiaoVideoUploadBody"></a>
## ToutiaoVideoUploadBody
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**video** | [**File**](#File) | 视频文件  |  required 

<markdown src="./File.md"/>
