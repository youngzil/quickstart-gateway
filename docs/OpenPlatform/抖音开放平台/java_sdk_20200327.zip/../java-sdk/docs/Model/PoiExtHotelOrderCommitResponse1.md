<a name="PoiExtHotelOrderCommitResponse1"></a>
## PoiExtHotelOrderCommitResponse1
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**date** | **String** | 入住日期 yyyyMMdd |  required 
**datePrice** | **Integer** | 入住日价格, 人民币分 |  required 



