<a name="FansProfileFlowContribution"></a>
## FansProfileFlowContribution
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**flow** | **String** | 流量贡献种类 |  required 
**fansSum** | **Integer** | 粉丝流量贡献 |  required 
**allSum** | **Integer** | 总流量贡献 |  required 




