<a name="PoiExtHotelOrderCommitResponse2"></a>
## PoiExtHotelOrderCommitResponse2
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**orderExtId** | **String** | 外部订单id |  required 
**errorCode** | **Integer** |  |  required 
**description** | **String** |  |  required 




