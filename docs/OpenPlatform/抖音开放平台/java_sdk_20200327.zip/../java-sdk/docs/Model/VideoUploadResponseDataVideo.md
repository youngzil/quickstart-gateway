<a name="VideoUploadResponseDataVideo"></a>
## VideoUploadResponseDataVideo
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**videoId** | **String** | 视频文件id。 |  required 
**width** | **Integer** |  |  required 
**height** | **Integer** |  |  required 




