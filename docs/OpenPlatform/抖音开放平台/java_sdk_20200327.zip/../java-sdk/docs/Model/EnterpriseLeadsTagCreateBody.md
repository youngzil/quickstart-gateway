<a name="EnterpriseLeadsTagCreateBody"></a>
## EnterpriseLeadsTagCreateBody
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**tagName** | **String** | 标签名称 |  required 


