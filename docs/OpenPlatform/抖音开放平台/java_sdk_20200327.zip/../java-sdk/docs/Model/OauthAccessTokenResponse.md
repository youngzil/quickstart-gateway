<a name="OauthAccessTokenResponse"></a>
## OauthAccessTokenResponse
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**message** | **String** |  |  optional
**data** | [**OauthAccessTokenResponseData**](#OauthAccessTokenResponseData) |  |  optional


<markdown src="./OauthAccessTokenResponseData.md"/>
