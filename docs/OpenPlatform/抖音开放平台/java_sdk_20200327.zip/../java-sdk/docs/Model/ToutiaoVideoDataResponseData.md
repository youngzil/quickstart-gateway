<a name="ToutiaoVideoDataResponseData"></a>
## ToutiaoVideoDataResponseData
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**errorCode** | **Integer** |  |  required 
**description** | **String** |  |  required 
**list** | [**List&lt;ToutiaoVideo&gt;**](#ToutiaoVideo) |  |  optional



<markdown src="./ToutiaoVideo.md"/>
