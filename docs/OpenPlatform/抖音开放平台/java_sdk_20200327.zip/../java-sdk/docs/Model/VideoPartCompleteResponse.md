<a name="VideoPartCompleteResponse"></a>
## VideoPartCompleteResponse
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**data** | [**VideoPartCompleteResponseData**](#VideoPartCompleteResponseData) |  |  optional

<markdown src="./VideoPartCompleteResponseData.md"/>
