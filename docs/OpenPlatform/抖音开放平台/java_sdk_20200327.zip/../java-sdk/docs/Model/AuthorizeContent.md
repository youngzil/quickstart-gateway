<a name="AuthorizeContent"></a>
## AuthorizeContent
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**scopes** | **List&lt;String&gt;** |  |  optional


