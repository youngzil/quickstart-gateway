<a name="DataExternalUserLikeResponseData"></a>
## DataExternalUserLikeResponseData
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**errorCode** | **Integer** |  |  required 
**description** | **String** |  |  required 
**resultList** | [**List&lt;ExternalUserLike&gt;**](#ExternalUserLike) |  |  optional



<markdown src="./ExternalUserLike.md"/>
