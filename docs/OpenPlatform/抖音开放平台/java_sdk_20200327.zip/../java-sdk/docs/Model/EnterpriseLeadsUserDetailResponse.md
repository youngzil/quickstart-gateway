<a name="EnterpriseLeadsUserDetailResponse"></a>
## EnterpriseLeadsUserDetailResponse
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**message** | **String** |  |  optional
**data** | [**EnterpriseLeadsUserDetailResponseData**](#EnterpriseLeadsUserDetailResponseData) |  |  optional


<markdown src="./EnterpriseLeadsUserDetailResponseData.md"/>
