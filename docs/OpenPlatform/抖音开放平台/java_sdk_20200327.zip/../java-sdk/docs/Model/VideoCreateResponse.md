<a name="VideoCreateResponse"></a>
## VideoCreateResponse
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**data** | [**VideoCreateResponseData**](#VideoCreateResponseData) |  |  optional
**extra** | [**Extra**](#Extra) |  |  optional

<markdown src="./VideoCreateResponseData.md"/>
<markdown src="./Extra.md"/>
