<a name="ExternalPoiBillboard"></a>
## ExternalPoiBillboard
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**poiId** | **String** | poi id |  optional
**poiName** | **String** | poi名称 |  optional
**score** | **String** | 得分 |  optional
**rank** | **Integer** | 排名 |  optional





