<a name="VideoPartUploadResponse"></a>
## VideoPartUploadResponse
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**data** | [**VideoPartUploadResponseData**](#VideoPartUploadResponseData) |  |  optional

<markdown src="./VideoPartUploadResponseData.md"/>
