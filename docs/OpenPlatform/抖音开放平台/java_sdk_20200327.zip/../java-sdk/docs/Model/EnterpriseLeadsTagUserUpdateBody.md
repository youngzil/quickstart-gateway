<a name="EnterpriseLeadsTagUserUpdateBody"></a>
## EnterpriseLeadsTagUserUpdateBody
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**tagId** | **Integer** | 标签id |  required 
**userId** | **String** | 用户openid |  required 
**bind** | **Boolean** | 是否绑定 |  required 




