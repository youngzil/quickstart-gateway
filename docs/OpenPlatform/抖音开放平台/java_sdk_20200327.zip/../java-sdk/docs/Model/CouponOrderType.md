# CouponOrderType

## Enum

* `GROUPON` (value: `"order_groupon"`)
