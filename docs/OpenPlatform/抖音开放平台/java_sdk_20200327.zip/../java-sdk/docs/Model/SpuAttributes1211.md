<a name="SpuAttributes1211"></a>
## SpuAttributes1211
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**checkInTime** | **String** | 入住时间(HH:mm) |  required 
**checkOutTime** | **String** | 离店时间(HH:mm) |  required 
**extra** | **String** | 出行提示自定义内容 |  optional




