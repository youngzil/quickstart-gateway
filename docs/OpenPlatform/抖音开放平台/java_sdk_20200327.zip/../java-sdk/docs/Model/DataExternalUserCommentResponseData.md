<a name="DataExternalUserCommentResponseData"></a>
## DataExternalUserCommentResponseData
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**errorCode** | **Integer** |  |  required 
**description** | **String** |  |  required 
**resultList** | [**List&lt;ExternalUserComment&gt;**](#ExternalUserComment) |  |  optional



<markdown src="./ExternalUserComment.md"/>
