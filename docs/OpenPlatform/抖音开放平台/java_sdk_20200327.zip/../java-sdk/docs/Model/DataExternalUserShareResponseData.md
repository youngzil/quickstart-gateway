<a name="DataExternalUserShareResponseData"></a>
## DataExternalUserShareResponseData
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**errorCode** | **Integer** |  |  required 
**description** | **String** |  |  required 
**resultList** | [**List&lt;ExternalUserShare&gt;**](#ExternalUserShare) |  |  optional



<markdown src="./ExternalUserShare.md"/>
