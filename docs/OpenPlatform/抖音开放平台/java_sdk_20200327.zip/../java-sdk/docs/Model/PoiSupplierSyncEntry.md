<a name="PoiSupplierSyncEntry"></a>
## PoiSupplierSyncEntry
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**entryType** | [**EnumEntryType**](#EnumEntryType) | 入口类型(1:H5，2:抖音小程序) |  optional
**entryMiniApp** | [**PoiSupplierSyncEntryResponse**](#PoiSupplierSyncEntryResponse) |  |  optional

<a name="EnumEntryType"></a>
### Enum: EnumEntryType
Name | Value
---- | -----
NUMBER_1 | 1
NUMBER_2 | 2


<markdown src="./PoiSupplierSyncEntryResponse.md"/>
