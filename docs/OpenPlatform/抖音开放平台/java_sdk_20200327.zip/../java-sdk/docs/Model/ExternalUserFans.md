<a name="ExternalUserFans"></a>
## ExternalUserFans
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**date** | **String** | 日期 |  optional
**totalFans** | **Integer** | 每日总粉丝数 |  optional
**newFans** | **Integer** | 每天新粉丝数 |  optional




