<a name="ExternalItemShare"></a>
## ExternalItemShare
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**date** | **String** | 日期 |  optional
**share** | **Integer** | 每日分享数 |  optional



