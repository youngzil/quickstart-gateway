<a name="PoiOrderSyncResponse1Data"></a>
## PoiOrderSyncResponse1Data
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**orderId** | **String** | 抖音平台订单ID |  required 
**errorCode** | **Integer** |  |  required 
**description** | **String** |  |  required 




