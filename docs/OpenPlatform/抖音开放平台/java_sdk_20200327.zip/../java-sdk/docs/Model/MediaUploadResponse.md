<a name="MediaUploadResponse"></a>
## MediaUploadResponse
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**data** | [**MediaUploadResponseData**](#MediaUploadResponseData) |  |  optional

<markdown src="./MediaUploadResponseData.md"/>
