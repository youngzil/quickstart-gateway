<a name="ExternalUserLike"></a>
## ExternalUserLike
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**date** | **String** | 日期 |  optional
**newLike** | **Integer** | 新增点赞 |  optional



