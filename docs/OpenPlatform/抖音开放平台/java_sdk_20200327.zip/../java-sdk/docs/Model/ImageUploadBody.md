<a name="ImageUploadBody"></a>
## ImageUploadBody
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**image** | [**File**](#File) | 图片 |  required 

<markdown src="./File.md"/>
