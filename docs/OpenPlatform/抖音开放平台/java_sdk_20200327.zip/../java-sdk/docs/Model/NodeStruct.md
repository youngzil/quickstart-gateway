<a name="NodeStruct"></a>
## NodeStruct
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**nodeType** | [**NodeTypeEnum**](#NodeTypeEnum) |  |  required 
**content** | **String** | 节点内容 |  optional

<markdown src="./NodeTypeEnum.md"/>

