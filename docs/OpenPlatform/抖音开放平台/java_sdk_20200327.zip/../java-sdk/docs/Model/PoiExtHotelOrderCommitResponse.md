<a name="PoiExtHotelOrderCommitResponse"></a>
## PoiExtHotelOrderCommitResponse
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**surname** | **String** | 英文姓 |  optional
**givenName** | **String** | 英文名 |  optional
**cnName** | **String** | 中文全称 |  optional




