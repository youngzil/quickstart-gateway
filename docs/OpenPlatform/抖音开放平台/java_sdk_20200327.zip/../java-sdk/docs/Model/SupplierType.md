# SupplierType

## Enum

* `NUMBER_1` (value: `1`)
* `NUMBER_2` (value: `2`)
* `NUMBER_3` (value: `3`)
* `NUMBER_4` (value: `4`)
* `NUMBER_5` (value: `5`)
* `NUMBER_6` (value: `6`)
* `NUMBER_7` (value: `7`)
* `NUMBER_8` (value: `8`)
* `NUMBER_9` (value: `9`)
* `NUMBER_10` (value: `10`)
* `NUMBER_11` (value: `11`)
* `NUMBER_12` (value: `12`)
