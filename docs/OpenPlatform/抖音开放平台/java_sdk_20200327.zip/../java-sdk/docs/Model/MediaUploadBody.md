<a name="MediaUploadBody"></a>
## MediaUploadBody
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**media** | [**File**](#File) | 素材文件 |  optional

<markdown src="./File.md"/>
