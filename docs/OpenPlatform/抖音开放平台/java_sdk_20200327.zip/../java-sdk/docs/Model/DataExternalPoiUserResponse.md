<a name="DataExternalPoiUserResponse"></a>
## DataExternalPoiUserResponse
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**data** | [**DataExternalPoiUserResponseData**](#DataExternalPoiUserResponseData) |  |  optional

<markdown src="./DataExternalPoiUserResponseData.md"/>
