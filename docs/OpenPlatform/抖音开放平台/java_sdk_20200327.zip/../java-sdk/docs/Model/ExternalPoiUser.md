<a name="ExternalPoiUser"></a>
## ExternalPoiUser
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**key** | **String** | key |  optional
**value** | **String** | value |  optional



