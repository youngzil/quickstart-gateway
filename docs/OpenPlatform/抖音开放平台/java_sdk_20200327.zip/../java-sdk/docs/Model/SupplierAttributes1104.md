<a name="SupplierAttributes1104"></a>
## SupplierAttributes1104
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**checkInTime** | **String** | 入住时间(HH:mm) |  required 
**checkOutTime** | **String** | 离店时间(HH:mm) |  required 
**breakfast** | [**SupplierAttributes1104Breakfast**](#SupplierAttributes1104Breakfast) |  |  required 
**child** | **String** | 儿童政策(&lt;&#x3D;500字) |  optional
**pet** | **String** | 宠物政策(&lt;&#x3D;500字) |  optional



<markdown src="./SupplierAttributes1104Breakfast.md"/>


