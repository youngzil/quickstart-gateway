<a name="DataExternalUserItemResponse"></a>
## DataExternalUserItemResponse
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**data** | [**DataExternalUserItemResponseData**](#DataExternalUserItemResponseData) |  |  optional

<markdown src="./DataExternalUserItemResponseData.md"/>
