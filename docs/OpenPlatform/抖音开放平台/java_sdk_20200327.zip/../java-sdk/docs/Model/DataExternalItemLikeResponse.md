<a name="DataExternalItemLikeResponse"></a>
## DataExternalItemLikeResponse
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**data** | [**DataExternalItemLikeResponseData**](#DataExternalItemLikeResponseData) |  |  optional

<markdown src="./DataExternalItemLikeResponseData.md"/>
