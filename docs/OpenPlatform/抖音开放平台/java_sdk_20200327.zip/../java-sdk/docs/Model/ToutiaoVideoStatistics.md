<a name="ToutiaoVideoStatistics"></a>
## ToutiaoVideoStatistics
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**commentCount** | **Integer** | 评论数 |  required 
**diggCount** | **Integer** | 点赞数 |  required 
**playCount** | **Integer** | 播放数 |  required 
**shareCount** | **Integer** | 分享数 |  required 
**forwardCount** | **Integer** | 转发数 |  required 






