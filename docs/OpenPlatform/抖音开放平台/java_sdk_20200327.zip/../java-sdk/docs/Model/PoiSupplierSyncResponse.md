<a name="PoiSupplierSyncResponse"></a>
## PoiSupplierSyncResponse
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**data** | [**PoiSupplierSyncResponseData**](#PoiSupplierSyncResponseData) |  |  required 

<markdown src="./PoiSupplierSyncResponseData.md"/>
