<a name="EventStatusListResponse"></a>
## EventStatusListResponse
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**data** | [**EventStatusListResponseData**](#EventStatusListResponseData) |  |  optional

<markdown src="./EventStatusListResponseData.md"/>
