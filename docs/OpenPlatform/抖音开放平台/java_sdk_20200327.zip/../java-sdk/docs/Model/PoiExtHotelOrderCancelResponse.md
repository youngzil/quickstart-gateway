<a name="PoiExtHotelOrderCancelResponse"></a>
## PoiExtHotelOrderCancelResponse
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**status** | [**EnumStatus**](#EnumStatus) | 取消订单确认状态码；0 - 接受取消 |  optional
**errorCode** | **Integer** |  |  required 
**description** | **String** |  |  required 

<a name="EnumStatus"></a>
### Enum: EnumStatus
Name | Value
---- | -----
NUMBER_0 | 0




