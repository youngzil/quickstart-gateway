<a name="SupplierAttributes1104Breakfast"></a>
## SupplierAttributes1104Breakfast
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**type** | [**EnumType**](#EnumType) | 早餐类型。0 - 无早餐, 1 - 早餐, 2 - 自助早餐 |  optional
**price** | **Integer** | 早餐价格(单位人民币分) |  optional

<a name="EnumType"></a>
### Enum: EnumType
Name | Value
---- | -----
NUMBER_0 | 0
NUMBER_1 | 1
NUMBER_2 | 2



