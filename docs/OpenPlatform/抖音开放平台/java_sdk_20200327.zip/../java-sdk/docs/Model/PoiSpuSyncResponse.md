<a name="PoiSpuSyncResponse"></a>
## PoiSpuSyncResponse
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**data** | [**PoiSpuSyncResponseData**](#PoiSpuSyncResponseData) |  |  required 

<markdown src="./PoiSpuSyncResponseData.md"/>
