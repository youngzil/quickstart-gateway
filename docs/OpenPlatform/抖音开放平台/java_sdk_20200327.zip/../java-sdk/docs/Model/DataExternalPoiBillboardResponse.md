<a name="DataExternalPoiBillboardResponse"></a>
## DataExternalPoiBillboardResponse
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**data** | [**DataExternalPoiBillboardResponseData**](#DataExternalPoiBillboardResponseData) |  |  optional

<markdown src="./DataExternalPoiBillboardResponseData.md"/>
