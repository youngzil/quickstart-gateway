<a name="DataExternalItemShareResponseData"></a>
## DataExternalItemShareResponseData
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**errorCode** | **Integer** |  |  required 
**description** | **String** |  |  required 
**resultList** | [**List&lt;ExternalItemShare&gt;**](#ExternalItemShare) |  |  optional



<markdown src="./ExternalItemShare.md"/>
