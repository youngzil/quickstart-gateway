<a name="SpuAttributes1212Response"></a>
## SpuAttributes1212Response
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**type** | [**EnumType**](#EnumType) | 加床政策; 0 - 不支持加床; 1 - 支持加床 |  required 
**price** | **Integer** | 加床费用/每人，单位人民币分 不支持加床填0 |  required 

<a name="EnumType"></a>
### Enum: EnumType
Name | Value
---- | -----
NUMBER_0 | 0
NUMBER_1 | 1



