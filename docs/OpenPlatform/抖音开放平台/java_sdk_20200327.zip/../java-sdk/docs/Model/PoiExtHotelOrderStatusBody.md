<a name="PoiExtHotelOrderStatusBody"></a>
## PoiExtHotelOrderStatusBody
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**supplierExtId** | **String** | 接入方商铺ID |  required 
**orderId** | **String** | 抖音订单号 |  required 
**orderExtId** | **String** | 接入方订单号 |  required 
**status** | **Integer** | 支付状态, 1 - 付款成功; |  required 





