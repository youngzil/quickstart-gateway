<a name="VideoPartInitResponseData"></a>
## VideoPartInitResponseData
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**uploadId** | **String** | 上传id |  optional
**errorCode** | **Integer** |  |  required 
**description** | **String** |  |  required 




