<a name="DataExternalItemCommentResponseData"></a>
## DataExternalItemCommentResponseData
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**errorCode** | **Integer** |  |  required 
**description** | **String** |  |  required 
**resultList** | [**List&lt;ExternalItemComment&gt;**](#ExternalItemComment) |  |  optional



<markdown src="./ExternalItemComment.md"/>
