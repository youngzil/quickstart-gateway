<a name="VideoUploadResponse"></a>
## VideoUploadResponse
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**data** | [**VideoUploadResponseData**](#VideoUploadResponseData) |  |  optional
**extra** | [**Extra**](#Extra) |  |  optional

<markdown src="./VideoUploadResponseData.md"/>
<markdown src="./Extra.md"/>
