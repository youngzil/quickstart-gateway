<a name="OauthClientTokenResponseData"></a>
## OauthClientTokenResponseData
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**errorCode** | **Integer** |  |  optional
**description** | **String** |  |  optional
**accessToken** | **String** | 接口调用凭证 |  optional
**expiresIn** | **String** | access_token接口调用凭证超时时间，单位（秒 |  optional





