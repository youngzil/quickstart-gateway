<a name="EnterpriseLeadsTagUserListResponseData"></a>
## EnterpriseLeadsTagUserListResponseData
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**errorCode** | **Integer** |  |  required 
**description** | **String** |  |  required 
**cursor** | **Long** |  |  required 
**hasMore** | **Boolean** |  |  required 
**list** | **List&lt;String&gt;** | 用户openid |  optional






