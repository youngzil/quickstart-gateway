<a name="ExtShopInfo"></a>
## ExtShopInfo
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**shopId** | **String** | 抖音商户ID |  optional
**extShopId** | **String** | 外部商户ID |  required 



