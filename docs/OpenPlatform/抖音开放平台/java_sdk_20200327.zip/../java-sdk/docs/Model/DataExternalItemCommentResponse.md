<a name="DataExternalItemCommentResponse"></a>
## DataExternalItemCommentResponse
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**data** | [**DataExternalItemCommentResponseData**](#DataExternalItemCommentResponseData) |  |  optional

<markdown src="./DataExternalItemCommentResponseData.md"/>
