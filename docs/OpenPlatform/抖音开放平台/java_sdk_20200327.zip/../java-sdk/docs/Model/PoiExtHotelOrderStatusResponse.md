<a name="PoiExtHotelOrderStatusResponse"></a>
## PoiExtHotelOrderStatusResponse
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**status** | [**ConfirmStatus**](#ConfirmStatus) |  |  optional
**errorCode** | **Integer** |  |  required 
**description** | **String** |  |  required 

<markdown src="./ConfirmStatus.md"/>


