<a name="DataExternalPoiUserResponseData"></a>
## DataExternalPoiUserResponseData
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**errorCode** | **Integer** |  |  required 
**description** | **String** |  |  required 
**genderList** | [**List&lt;ExternalPoiUser&gt;**](#ExternalPoiUser) |  |  optional
**ageList** | [**List&lt;ExternalPoiUser&gt;**](#ExternalPoiUser) |  |  optional
**cityList** | [**List&lt;ExternalPoiUser&gt;**](#ExternalPoiUser) |  |  optional



<markdown src="./ExternalPoiUser.md"/>
<markdown src="./ExternalPoiUser.md"/>
<markdown src="./ExternalPoiUser.md"/>
