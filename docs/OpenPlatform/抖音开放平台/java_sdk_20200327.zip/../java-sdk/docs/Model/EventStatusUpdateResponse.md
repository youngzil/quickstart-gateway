<a name="EventStatusUpdateResponse"></a>
## EventStatusUpdateResponse
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**data** | [**EventStatusUpdateResponseData**](#EventStatusUpdateResponseData) |  |  optional

<markdown src="./EventStatusUpdateResponseData.md"/>
