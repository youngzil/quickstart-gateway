<a name="CreateVideo"></a>
## CreateVideo
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**event** | **String** | 事件名为create_video |  optional
**fromUserId** | **String** | 发起用户user_id |  optional
**clientKey** | **String** | 使用应用的client_key |  optional
**content** | [**CreateVideoContent**](#CreateVideoContent) |  |  optional




<markdown src="./CreateVideoContent.md"/>
