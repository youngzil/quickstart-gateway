<a name="DataExternalUserLikeResponse"></a>
## DataExternalUserLikeResponse
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**data** | [**DataExternalUserLikeResponseData**](#DataExternalUserLikeResponseData) |  |  optional

<markdown src="./DataExternalUserLikeResponseData.md"/>
