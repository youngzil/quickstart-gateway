<a name="ExternalUserComment"></a>
## ExternalUserComment
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**date** | **String** | 日期 |  optional
**newComment** | **Integer** | 新增评论 |  optional



