<a name="VideoCommentTopBody"></a>
## VideoCommentTopBody
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**itemId** | **String** | 视频id |  required 
**commentId** | **String** | 需要回复的评论id |  required 
**top** | **Boolean** | true: 置顶, false: 取消置顶 |  required 




