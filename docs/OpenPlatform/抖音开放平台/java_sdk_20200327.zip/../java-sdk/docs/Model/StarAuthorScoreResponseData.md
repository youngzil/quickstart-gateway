<a name="StarAuthorScoreResponseData"></a>
## StarAuthorScoreResponseData
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**errorCode** | **Integer** |  |  required 
**description** | **String** |  |  required 
**updateTimestamp** | **Integer** | 达人指数更新时间戳 |  optional
**nickName** | **String** | 达人昵称 |  optional
**follower** | **Integer** | 粉丝数 |  optional
**spreadScore** | **Double** | 传播指数 |  optional
**cpScore** | **Double** | 性价比指数 |  optional
**growthScore** | **Double** | 涨粉指数 |  optional
**cooperationScore** | **Double** | 合作指数 |  optional
**shopScore** | **Double** | 种草指数 |  optional
**starScore** | **Double** | 星图指数 |  optional












