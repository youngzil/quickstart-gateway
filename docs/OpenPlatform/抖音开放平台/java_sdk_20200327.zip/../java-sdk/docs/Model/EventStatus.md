<a name="EventStatus"></a>
## EventStatus
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**event** | **String** | 推送事件名称 |  required 
**status** | [**EnumStatus**](#EnumStatus) | 事件订阅状态 * &#x60;0&#x60; - 未订阅 * &#x60;1&#x60; - 已订阅 |  required 

<a name="EnumStatus"></a>
### Enum: EnumStatus
Name | Value
---- | -----
NUMBER_0 | 0
NUMBER_1 | 1



