<a name="HotsearchTrendingSentencesResponse"></a>
## HotsearchTrendingSentencesResponse
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**data** | [**HotsearchTrendingSentencesResponseData**](#HotsearchTrendingSentencesResponseData) |  |  optional

<markdown src="./HotsearchTrendingSentencesResponseData.md"/>
