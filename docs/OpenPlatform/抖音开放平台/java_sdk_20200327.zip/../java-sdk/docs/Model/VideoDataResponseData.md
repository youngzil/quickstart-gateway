<a name="VideoDataResponseData"></a>
## VideoDataResponseData
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**errorCode** | **Integer** |  |  required 
**description** | **String** |  |  required 
**videoData** | [**List&lt;VideoDataResponseDataResponse&gt;**](#VideoDataResponseDataResponse) | 见list |  required 
**list** | [**List&lt;Video&gt;**](#Video) |  |  optional



<markdown src="./VideoDataResponseDataResponse.md"/>
<markdown src="./Video.md"/>
