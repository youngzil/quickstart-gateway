<a name="FansProfileDistribution"></a>
## FansProfileDistribution
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**item** | **String** | 分布的种类 |  required 
**value** | **Integer** | 分布的数值 |  required 



