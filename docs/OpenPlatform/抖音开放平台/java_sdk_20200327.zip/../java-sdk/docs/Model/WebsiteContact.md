<a name="WebsiteContact"></a>
## WebsiteContact
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**event** | **String** | 事件名为website_contact |  optional
**fromUserId** | **String** | 事件发起用户user_id |  optional
**toUserId** | **String** | 事件接收用户user_id |  optional
**clientKey** | **String** | 使用应用的client_key |  optional





