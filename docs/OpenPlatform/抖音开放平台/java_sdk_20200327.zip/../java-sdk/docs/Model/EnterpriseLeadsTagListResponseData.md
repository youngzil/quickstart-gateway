<a name="EnterpriseLeadsTagListResponseData"></a>
## EnterpriseLeadsTagListResponseData
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**errorCode** | **Integer** |  |  required 
**description** | **String** |  |  required 
**cursor** | **Long** |  |  required 
**hasMore** | **Boolean** |  |  required 
**list** | [**List&lt;EnterpriseLeadsUserListResponseDataResponse&gt;**](#EnterpriseLeadsUserListResponseDataResponse) |  |  optional





<markdown src="./EnterpriseLeadsUserListResponseDataResponse.md"/>
