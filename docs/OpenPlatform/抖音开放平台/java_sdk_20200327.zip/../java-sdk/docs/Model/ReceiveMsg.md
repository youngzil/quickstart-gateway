<a name="ReceiveMsg"></a>
## ReceiveMsg
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**event** | **String** | 事件名为receive_msg |  optional
**fromUserId** | **String** | 事件发起用户user_id |  optional
**toUserId** | **String** | 事件接收用户user_id |  optional
**clientKey** | **String** | 使用应用的client_key |  optional
**content** | **Object** | 具体见私信事件列表 |  optional






