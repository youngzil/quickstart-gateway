<a name="DataExternalItemBaseResponse"></a>
## DataExternalItemBaseResponse
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**data** | [**DataExternalItemBaseResponseData**](#DataExternalItemBaseResponseData) |  |  optional

<markdown src="./DataExternalItemBaseResponseData.md"/>
