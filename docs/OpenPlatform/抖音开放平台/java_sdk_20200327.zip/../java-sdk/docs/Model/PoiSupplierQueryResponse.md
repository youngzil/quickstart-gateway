<a name="PoiSupplierQueryResponse"></a>
## PoiSupplierQueryResponse
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**data** | [**PoiSupplierQueryResponseData**](#PoiSupplierQueryResponseData) |  |  required 

<markdown src="./PoiSupplierQueryResponseData.md"/>
