<a name="ExternalUserProfile"></a>
## ExternalUserProfile
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**date** | **String** | 日期 |  optional
**profileUv** | **Integer** | 当日个人主页访问人数 |  optional



