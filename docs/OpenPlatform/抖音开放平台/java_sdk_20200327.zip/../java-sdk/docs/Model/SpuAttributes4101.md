<a name="SpuAttributes4101"></a>
## SpuAttributes4101
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**marketPrice** | **Integer** | 原价 单位：分 |  optional
**discountPrice** | **Integer** | 售价 单位：分 |  optional
**img** | **String** | 商品图片 |  optional
**selledNum** | **Integer** | 销量 |  optional
**detailEntry** | [**SpuAttributes4101Response**](#SpuAttributes4101Response) |  |  optional





<markdown src="./SpuAttributes4101Response.md"/>
