<a name="CallMetrics"></a>
## CallMetrics
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**dateTime** | **String** | 时间 |  required 
**scope** | **String** | scope |  optional
**_interface** | **String** | 访问链接 |  optional
**pv** | **Integer** | pv |  required 





