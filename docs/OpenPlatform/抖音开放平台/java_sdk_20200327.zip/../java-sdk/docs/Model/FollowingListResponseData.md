<a name="FollowingListResponseData"></a>
## FollowingListResponseData
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**errorCode** | **Integer** |  |  optional
**description** | **String** |  |  optional
**cursor** | **Long** |  |  optional
**hasMore** | **Boolean** |  |  optional
**list** | [**List&lt;User&gt;**](#User) |  |  optional





<markdown src="./User.md"/>
