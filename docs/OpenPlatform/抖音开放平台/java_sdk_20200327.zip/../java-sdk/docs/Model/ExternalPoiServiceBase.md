<a name="ExternalPoiServiceBase"></a>
## ExternalPoiServiceBase
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**date** | **String** | 日期 |  optional
**exposureUv** | **Integer** | 曝光uv |  optional
**clickUv** | **Integer** | 点击uv |  optional
**successOrderCnt** | **Integer** | 订房成交次数 |  optional





