<a name="DataExternalPoiServiceBaseResponseData"></a>
## DataExternalPoiServiceBaseResponseData
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**errorCode** | **Integer** |  |  required 
**description** | **String** |  |  required 
**resultList** | [**List&lt;ExternalPoiServiceBase&gt;**](#ExternalPoiServiceBase) |  |  optional



<markdown src="./ExternalPoiServiceBase.md"/>
