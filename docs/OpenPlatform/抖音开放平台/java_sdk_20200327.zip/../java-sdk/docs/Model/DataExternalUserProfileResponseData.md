<a name="DataExternalUserProfileResponseData"></a>
## DataExternalUserProfileResponseData
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**errorCode** | **Integer** |  |  required 
**description** | **String** |  |  required 
**resultList** | [**List&lt;ExternalUserProfile&gt;**](#ExternalUserProfile) |  |  optional



<markdown src="./ExternalUserProfile.md"/>
