<a name="VideoCommentListResponse"></a>
## VideoCommentListResponse
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**data** | [**VideoCommentListResponseData**](#VideoCommentListResponseData) |  |  required 

<markdown src="./VideoCommentListResponseData.md"/>
