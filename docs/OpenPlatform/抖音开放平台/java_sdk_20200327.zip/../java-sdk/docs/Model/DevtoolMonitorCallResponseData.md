<a name="DevtoolMonitorCallResponseData"></a>
## DevtoolMonitorCallResponseData
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**errorCode** | **Integer** |  |  required 
**description** | **String** |  |  required 
**resultList** | [**List&lt;CallMetrics&gt;**](#CallMetrics) |  |  optional



<markdown src="./CallMetrics.md"/>
