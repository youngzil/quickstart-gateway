<a name="VideoListResponseData"></a>
## VideoListResponseData
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**errorCode** | **Integer** |  |  required 
**description** | **String** |  |  required 
**cursor** | **Long** |  |  required 
**hasMore** | **Boolean** |  |  required 
**list** | [**List&lt;Video&gt;**](#Video) | 由于置顶的原因, list长度可能比count指定的数量多一些或少一些。 |  optional





<markdown src="./Video.md"/>
