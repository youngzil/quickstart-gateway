<a name="ImageCreateResponse"></a>
## ImageCreateResponse
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**data** | [**ImageCreateResponseData**](#ImageCreateResponseData) |  |  optional

<markdown src="./ImageCreateResponseData.md"/>
