<a name="SupplierAttributes3101Response"></a>
## SupplierAttributes3101Response
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**population** | **String** | 优待政策-人群(婴儿、儿童、老人、军人、残障人士，不超过30个汉字) |  optional
**condition** | **String** | 优待政策-适用条件(不超过200个汉字) |  optional
**discount** | **String** | 优待政策-优待内容(免费、优惠、半价) |  optional




