<a name="DataExternalUserFansResponse"></a>
## DataExternalUserFansResponse
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**data** | [**DataExternalUserFansResponseData**](#DataExternalUserFansResponseData) |  |  optional

<markdown src="./DataExternalUserFansResponseData.md"/>
