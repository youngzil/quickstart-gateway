<a name="ImMessageSendResponse"></a>
## ImMessageSendResponse
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**data** | [**ImMessageSendResponseData**](#ImMessageSendResponseData) |  |  optional

<markdown src="./ImMessageSendResponseData.md"/>
