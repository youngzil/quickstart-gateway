<a name="EventStatusUpdateBody"></a>
## EventStatusUpdateBody
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**list** | [**List&lt;EventStatus&gt;**](#EventStatus) |  |  required 

<markdown src="./EventStatus.md"/>
