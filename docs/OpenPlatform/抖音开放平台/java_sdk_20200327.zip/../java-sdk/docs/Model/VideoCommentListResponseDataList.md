<a name="VideoCommentListResponseDataList"></a>
## VideoCommentListResponseDataList
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**commentId** | **String** |  |  required 
**commentUserId** | **String** |  |  required 
**content** | **String** |  |  required 
**createTime** | **Integer** | 时间戳 |  required 
**top** | **Boolean** | 是否置顶评论 |  required 
**diggCount** | **Integer** |  |  required 
**replyCommentTotal** | **Integer** | 回复评论数 |  required 








