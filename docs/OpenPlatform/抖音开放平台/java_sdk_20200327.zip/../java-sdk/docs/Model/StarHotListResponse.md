<a name="StarHotListResponse"></a>
## StarHotListResponse
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**data** | [**StarHotListResponseData**](#StarHotListResponseData) |  |  optional

<markdown src="./StarHotListResponseData.md"/>
