<a name="StarHotListResponseData"></a>
## StarHotListResponseData
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**errorCode** | **Integer** |  |  required 
**description** | **String** |  |  required 
**hotListUpdateTimestamp** | **Integer** | 达人热榜更新时间戳 |  optional
**hotListType** | **Integer** | 达人热榜类型 |  optional
**hotListDescription** | **String** | 热榜类型说明 |  optional
**list** | [**List&lt;StarHotListResponseDataList&gt;**](#StarHotListResponseDataList) |  |  optional






<markdown src="./StarHotListResponseDataList.md"/>
