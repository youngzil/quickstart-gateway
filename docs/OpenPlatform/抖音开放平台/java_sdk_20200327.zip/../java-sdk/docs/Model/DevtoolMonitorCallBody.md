<a name="DevtoolMonitorCallBody"></a>
## DevtoolMonitorCallBody
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**scopeList** | **List&lt;String&gt;** | scope支持批量查询 |  optional
**interfaceList** | **List&lt;String&gt;** | 接口支持批量查询 |  optional



