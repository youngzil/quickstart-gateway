<a name="VideoDeleteResponse"></a>
## VideoDeleteResponse
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**data** | [**VideoDeleteResponseData**](#VideoDeleteResponseData) |  |  optional

<markdown src="./VideoDeleteResponseData.md"/>
