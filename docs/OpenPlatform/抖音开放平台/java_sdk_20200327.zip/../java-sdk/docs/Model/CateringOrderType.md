# CateringOrderType

## Enum

* `MENU` (value: `"order_menu"`)
* `QUEUE` (value: `"order_queue"`)
* `BOOK` (value: `"order_book"`)
