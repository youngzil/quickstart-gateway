<a name="ExternalUserItem"></a>
## ExternalUserItem
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**date** | **String** | 日期 |  optional
**newPlay** | **Integer** | 每天新增视频播放 |  optional
**newIssue** | **Integer** | 每日发布内容数 |  optional
**totalIssue** | **Integer** | 每日内容总数 |  optional





