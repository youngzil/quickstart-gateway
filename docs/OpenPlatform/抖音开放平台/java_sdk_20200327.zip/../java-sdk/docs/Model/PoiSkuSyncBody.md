<a name="PoiSkuSyncBody"></a>
## PoiSkuSyncBody
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**spuExtId** | **String** | 外部平台SPU ID |  required 
**skus** | [**List&lt;PoiSkuSyncSkus&gt;**](#PoiSkuSyncSkus) |  |  required 


<markdown src="./PoiSkuSyncSkus.md"/>
