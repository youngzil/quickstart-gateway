<a name="SupplierAttributes"></a>
## SupplierAttributes
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**_1101** | [**List&lt;HotelServiceFacility&gt;**](#HotelServiceFacility) | 酒店服务 |  optional
**_1102** | [**List&lt;HotelServiceFacility&gt;**](#HotelServiceFacility) | 酒店设施 |  optional
**_1103** | [**List&lt;HotelServiceFacility&gt;**](#HotelServiceFacility) | 酒店特色项目 |  optional
**_1104** | [**SupplierAttributes1104**](#SupplierAttributes1104) |  |  optional
**_1105** | [**Enum1105**](#Enum1105) | 下单模板。1 - 国内模板, 2 - 海外模板 |  optional
**_3101** | [**SupplierAttributes3101**](#SupplierAttributes3101) |  |  optional

<a name="Enum1105"></a>
### Enum: Enum1105
Name | Value
---- | -----
NUMBER_1 | 1
NUMBER_2 | 2

<markdown src="./HotelServiceFacility.md"/>
<markdown src="./HotelServiceFacility.md"/>
<markdown src="./HotelServiceFacility.md"/>
<markdown src="./SupplierAttributes1104.md"/>

<markdown src="./SupplierAttributes3101.md"/>
