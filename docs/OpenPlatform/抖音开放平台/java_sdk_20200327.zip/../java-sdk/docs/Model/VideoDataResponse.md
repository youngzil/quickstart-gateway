<a name="VideoDataResponse"></a>
## VideoDataResponse
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**data** | [**VideoDataResponseData**](#VideoDataResponseData) |  |  optional

<markdown src="./VideoDataResponseData.md"/>
