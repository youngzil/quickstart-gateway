<a name="StarHotListResponseDataList"></a>
## StarHotListResponseDataList
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**rank** | **Integer** | 热榜排名 |  required 
**nickName** | **String** | 达人昵称 |  required 
**tags** | **List&lt;String&gt;** |  |  required 
**follower** | **Integer** | 粉丝数 |  required 
**score** | **Double** | 热榜类型对应的热榜指数 |  required 






