<a name="HotsearchVideosResponseData"></a>
## HotsearchVideosResponseData
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**errorCode** | **Integer** |  |  required 
**description** | **String** |  |  required 
**list** | [**List&lt;Video&gt;**](#Video) | 视频列表 |  optional



<markdown src="./Video.md"/>
