<a name="HotsearchVideosResponse"></a>
## HotsearchVideosResponse
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**data** | [**HotsearchVideosResponseData**](#HotsearchVideosResponseData) |  |  optional

<markdown src="./HotsearchVideosResponseData.md"/>
