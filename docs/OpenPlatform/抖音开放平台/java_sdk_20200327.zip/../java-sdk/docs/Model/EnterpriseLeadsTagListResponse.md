<a name="EnterpriseLeadsTagListResponse"></a>
## EnterpriseLeadsTagListResponse
### 属性
参数名 | 参数类型 | 参数描述 | 备注
------------ | ------------- | ------------- | -------------
**data** | [**EnterpriseLeadsTagListResponseData**](#EnterpriseLeadsTagListResponseData) |  |  optional

<markdown src="./EnterpriseLeadsTagListResponseData.md"/>
