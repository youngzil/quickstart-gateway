# ConfirmStatus

## Enum

* `NUMBER_0` (value: `0`)
* `NUMBER_1` (value: `1`)
* `NUMBER_2` (value: `2`)
* `NUMBER_3` (value: `3`)
